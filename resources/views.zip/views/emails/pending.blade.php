<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale = 1.0">
	<title>Notification</title>
</head>
<body style="margin: 0; padding: 0;">
    <table width= "100%" align="center" cellspacing="0" cellpadding="0" style="border: 1px groove cornflowerblue; max-width: 600px;">
    	<tr>
    		<td align="center" width="100%">
           
                <a href="{{url('/')}}" class="logo-content-small" title="Kobowise">
            Virgin Forest
                </a>
            </td>
    	</tr>
    	  <tr>
            <td style="padding: 0 5% 0 5%">
                <p align="center" style="font-family: 'Arial Rounded MT Bold',serif; font-size: large; font-weight: 600">Hi</p>
                <p>You have pending activity that need your approvers</p>
                <p><a href="{{url('/')}}" target="_blank">Click</a> to Login </p>
                <p>Thank you. </p>
                
            </td>
        </tr>
         </table>
</body>
</html>