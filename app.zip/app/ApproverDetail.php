<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ApproverDetail extends Model
{
    //
}
