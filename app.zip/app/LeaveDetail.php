<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LeaveDetail extends Model
{
    //
}
